/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculating.polygon.field;

/**
 *
 * @author Dominik Figlak
 * @version 1.0
 */
public interface Distance {
    Float calculateDistance(Vector2 firstVertex, Vector2 secoundVertex);
}
