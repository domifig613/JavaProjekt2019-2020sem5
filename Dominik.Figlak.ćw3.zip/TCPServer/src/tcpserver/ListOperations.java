package tcpserver;
/**
 * Class that stores a collection of numbers
 * @author Dominik Figlak 
 * @version 1.0
 */
public class ListOperations {
/**
 * A method showing how give data to server
 * @return string
 */

public static String showHowCommunicate() {
    return "Give all vertices in order to get polygon field: vertex: one float, space, secound float"
            + " space next vertex";
}
/**
 * A method showing method of calculate
 * @return string
 */

public static String showCalculateMethod() {
    return "Server use Pick's theorem";
}
}
