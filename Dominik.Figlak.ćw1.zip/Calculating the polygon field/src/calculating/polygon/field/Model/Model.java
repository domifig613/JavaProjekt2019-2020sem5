/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculating.polygon.field.Model;

/**
 *
 * @author domin
 * @version 1.0
 */
public class Model {
    
    
     /**
     * Checks for arguments
     * @param arguments
     * @return
     */
    public boolean areArguments(String[] arguments){
        return arguments.length > 0;
    }
    
    /**
     * Calculate polygon field
     * @param vertices
     */
    public void calculatePolygonField(float[] vertices){
        try{
            if(vertices.length < 3){
                throw new NotPolygonException("polygon should has more than 2 vertices");  
            }
        }
        catch(NotPolygonException ex){
           System.err.println(ex.getMessage());
       }
    }
}

class NotPolygonException extends Exception {

    /**
     * Non-parameter constructor
     */
    public NotPolygonException() {
    }
    
    public NotPolygonException(String message){
        super(message);
    }
}