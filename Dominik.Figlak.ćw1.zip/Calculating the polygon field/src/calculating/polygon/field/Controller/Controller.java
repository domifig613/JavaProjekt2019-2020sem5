/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculating.polygon.field.Controller;

import calculating.polygon.field.View.View;
import java.util.Scanner;
import java.util.InputMismatchException;

/**
 * Class collects data from the user
 * @author Dominik Figlak
 * @version 1.1
 */
public class Controller {
    
    /**
     * Take points from user
     * @param view
     * @return
     */
    public float[] getArguments(View view){
        float[] vertices;
        Scanner input = new Scanner(System.in);
        view.starGetVerticesFromInput();

        int count = getIntFromInput(input, view);
      
        vertices = new float[count];
        
        for(int i=0; i<vertices.length; i++){
            view.toGetFloat();
            
            if(input.toString().length() == 0)
            {
                break;
            }
            
            try {
                vertices[i] = input.nextFloat();
            }
            catch (InputMismatchException ime) {
                view.badNumberInInput();
                input.next(); // Flush the buffer from all data
                i--;
            }
        }
        return vertices;
    }
    
    /**
     * Parse arguments from input
     * @param arguments
     * @param view
     * @return
     */
    public float[] parseArguments(String[] arguments, View view){
        float[] vertices = new float[arguments.length];
        for(int index = 0; index < arguments.length; index++){
            try{
                vertices[index] = Float.parseFloat(arguments[index].trim());
            }
            catch (RuntimeException argument){
                view.floatParseError(argument);
                view.messageBeforeExit();
            }
        }
        return vertices;
    }
    
    
    
    private int getIntFromInput(Scanner input, View view){
        int count = 0;

        while(count == 0){
            try {
                count = input.nextInt();
            }
            catch (InputMismatchException ime) {
                view.badNumberInInput();
                input.next();
            }
        }
        return count;
    }
}

